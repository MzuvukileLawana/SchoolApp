﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolReports
{
    class Program
    {
        static void Main(string[] args)
        {
           
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-5CD7243\\SQLEXPRESS;Initial Catalog=SchoolApp;Integrated Security=True");
            try
            {
                

                SqlCommand cmd = null;
                conn.Open();

                Console.WriteLine("1 for Child Mark Report: ");
                Console.WriteLine("2 for Class Averages Report: ");
                Console.WriteLine("3 for Sports Taken: ");
                Console.WriteLine("");
                Console.WriteLine("Enter a number from 1 - 3: ");
                string reportName = string.Empty;
 
                int menuchoice = int.Parse(Console.ReadLine());
 
                switch (menuchoice)
                {
                    case 1:
                        reportName = "ChildMarkReport.txt";
                        Console.WriteLine("-------------------------------------------------");
                        Console.WriteLine("Child Mark Report");
                        Console.WriteLine("-------------------------------------------------");

                        cmd = new SqlCommand("select_student_mark", conn);
                        Console.WriteLine("Enter Student Name or Press enter to view all students: ");
                        string name = Console.ReadLine();
                        string surname = string.Empty;
                        
                        if (name == string.Empty)
                        {
                            name = null;
                            surname = null;
                        }
                        else
                        {
                            Console.WriteLine("Enter Student Surname: ");
                            surname = Console.ReadLine();
                        }
                        
                        cmd.Parameters.Add(new SqlParameter("@name", name));
                        cmd.Parameters.Add(new SqlParameter("@surname", surname));

                       
                        break;
                    case 2:
                        reportName = "ClassAverageReport.txt";
                        Console.WriteLine("Class Averages Report");
                        cmd = new SqlCommand("select_amount_of_subjects_taken", conn);
                        
                        break;
                    case 3:
                        reportName = "SportTaken.txt";
                        Console.WriteLine("Sports Taken");
                        cmd = new SqlCommand("select_student_sport", conn);
                        break;
                    default:
                        Console.WriteLine("Sorry, invalid selection");
                        break;
                }

                cmd.CommandType = CommandType.StoredProcedure;
                int rows = cmd.ExecuteNonQuery();


                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    
                    if (reader.HasRows)
                    {
                        int ColumnCount = reader.FieldCount;
                        string ListOfColumns = string.Empty;
                        while (reader.Read())
                        {
                            for (int i = 0; i < ColumnCount; i++)
                            {
                                ListOfColumns = ListOfColumns + reader[i].ToString() + "|";
                            }
                            ListOfColumns = ListOfColumns + Environment.NewLine;
                            Console.WriteLine();
                        }
                        
                        TextWriter tw = new StreamWriter("C:\\Users\\Net2\\Documents\\" + reportName);
                      
                        tw.WriteLine(ListOfColumns);
                        tw.Close();
                        Console.WriteLine("Successfully");
                    }
                    else
                    {
                        Console.WriteLine("No rows returned, please ensure student name and surname is entered correctly");
                    }
                   
                }
                
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            Console.WriteLine("");
            Console.WriteLine("Press any key to exit: ");
            Console.ReadKey();
            
        }
       
    }
}
